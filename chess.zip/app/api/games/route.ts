import { getPrisma } from "../../lib/db";
import { GAME_ID_PATTERN, parseSaveRequest } from "../../lib/game-record";

const PAGE_SIZE = 20;

const STORED_GAME_SELECT = {
  id: true,
  playedAt: true,
  pgn: true,
  plies: true,
  humanColor: true,
  result: true,
  termination: true,
  engineLevel: true,
  clockMinutes: true,
  clockIncrementSeconds: true,
} as const;

function unavailable(error: unknown): Response {
  console.error("Game history database error:", error);
  return Response.json({ error: "Database unavailable." }, { status: 503 });
}

// Newest first. `?cursor=<id>` continues after that game; `nextCursor` is null
// on the last page.
export async function GET(request: Request): Promise<Response> {
  const cursor = new URL(request.url).searchParams.get("cursor");
  if (cursor !== null && !GAME_ID_PATTERN.test(cursor)) {
    return Response.json({ error: "Invalid cursor." }, { status: 400 });
  }

  try {
    const rows = await getPrisma().game.findMany({
      orderBy: [{ playedAt: "desc" }, { id: "desc" }],
      take: PAGE_SIZE + 1,
      ...(cursor ? { cursor: { id: cursor }, skip: 1 } : {}),
      select: STORED_GAME_SELECT,
    });
    const games = rows.slice(0, PAGE_SIZE);
    const nextCursor =
      rows.length > PAGE_SIZE ? games[games.length - 1].id : null;
    return Response.json({ games, nextCursor });
  } catch (error) {
    return unavailable(error);
  }
}

// Saves a finished game. The same id can be posted again (for example when an
// undo after checkmate leads to a different ending) and replaces the row.
export async function POST(request: Request): Promise<Response> {
  let body: unknown;
  try {
    body = await request.json();
  } catch {
    return Response.json({ error: "Body must be JSON." }, { status: 400 });
  }

  const now = new Date();
  const parsed = parseSaveRequest(body, now);
  if (!parsed.ok) {
    return Response.json({ error: parsed.error }, { status: 400 });
  }

  const { id, ...data } = parsed.record;
  try {
    await getPrisma().game.upsert({
      where: { id },
      create: { id, ...data, playedAt: now },
      update: { ...data, playedAt: now },
    });
    return Response.json({ id });
  } catch (error) {
    return unavailable(error);
  }
}
