import { getPrisma } from "../../../lib/db";
import { GAME_ID_PATTERN } from "../../../lib/game-record";

// Deleting a game that is already gone still succeeds, so a retry is harmless.
export async function DELETE(
  _request: Request,
  ctx: { params: Promise<{ id: string }> },
): Promise<Response> {
  const { id } = await ctx.params;
  if (!GAME_ID_PATTERN.test(id)) {
    return Response.json({ error: "Invalid game id." }, { status: 400 });
  }
  try {
    await getPrisma().game.deleteMany({ where: { id } });
    return new Response(null, { status: 204 });
  } catch (error) {
    console.error("Game history database error:", error);
    return Response.json({ error: "Database unavailable." }, { status: 503 });
  }
}
